#include <iostream>
using namespace std;
int main(){
    int input[3]; 
    string in;
    struct stru
    {
        int num;
        char ch;
    };
    stru a,b,c;
    for (int i = 0; i < 3; i++)
    {
        cin >> input[i];
    }
    cin >> in;
    
    
}