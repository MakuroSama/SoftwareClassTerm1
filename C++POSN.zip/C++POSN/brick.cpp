#include<bits/stdc++.h>
using namespace std;
int main(){
    int n,m;
    string str;
    vector<string> game;
    vector<int> brick;
    cin >> n >> m;
    for (int i = 0; i < n; i++)
    {
        cin >> str;
        game.push_back(str);
    }
    
}