from tkinter import *

def main():
    root = Tk()
    root.title("Login System")
    root.geometry("300x650")
    
    teacherImg = PhotoImage(file="D:\\021399\pythonApp\image\\teacher.png")
    studentImg = PhotoImage(file="D:\\021399\pythonApp\image\student.png")
    subjectImg = PhotoImage(file="D:\\021399\pythonApp\image\subject.png")
    registerImg = PhotoImage(file="D:\\021399\pythonApp\image\login.png")
    exitImg = PhotoImage(file="D:\\021399\pythonApp\image\logout.png")
    btn1 = Button(root, text="teacher",image=teacherImg,compound="left", width=180, height=90)
    btn2 = Button(root, text="student",image=studentImg,compound="left", width=180, height=90)
    btn3 = Button(root, text="subjects",image=subjectImg,compound="left", width=180, height=90)
    btn4 = Button(root, text="registraion",image=registerImg,compound="left", width=180, height=90)
    btn5 = Button(root, text="exit",image=exitImg,compound="left", width=180, height=90)
    
    btn1.pack(pady=10)
    btn2.pack(pady=10)
    btn3.pack(pady=10)
    btn4.pack(pady=10)
    btn5.pack(pady=10)
   

    root.mainloop()
if __name__ == "__main__":
    main()